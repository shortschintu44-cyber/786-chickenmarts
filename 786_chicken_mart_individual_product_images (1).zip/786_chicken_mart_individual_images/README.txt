786 CHICKEN MART WEBSITE — UPDATED PRODUCT CATALOGUE
The 22 listed catalogue items come from your screenshots plus your original five confirmed price items.
Open index.html in a browser to preview locally. Extract the ZIP first and keep all files together.
Edit config.js to update product names, prices, images, availability, WhatsApp and delivery settings.
Prices shown in the screenshots were added where readable. Items without a clearly shown price display “Price to be confirmed” and cannot be added until you set a price.
Your screenshots are used as reference images across cards; individual cropped product photos would look more polished.
WhatsApp checkout prepares an order message for customer review. There is no online payment, database, or order tracking.

Individual product image crops were created from the product reference screenshots and assigned to each catalogue item. Replace with original high-resolution product photography when available.
