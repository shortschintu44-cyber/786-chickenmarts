// Owner settings: edit product names, prices, images and availability here.
window.SHOP_CONFIG = {
  whatsapp: "919701194482", phoneDisplay: "9701194482",
  deliveryRadius: "5–7 km", deliveryHours: "6:00 AM–6:00 PM", freeMasala: true,
  products: [
    {id:"curry-skin-off",name:"Chicken Curry Cut (Skin Off)",price:169,category:"broiler",image:"images/curry-skin-off.jpg",available:true,description:"Customise your product · starts from"},
    {id:"liver",name:"Chicken Liver",price:49,category:"broiler",image:"images/liver.jpg",available:true,description:"190–210 g pack · screenshot price"},
    {id:"curry-skin-on",name:"Chicken Curry Cut (Skin On)",price:165,category:"broiler",image:"images/curry-skin-on.jpg",available:true,description:"Customise your product · starts from"},
    {id:"wings",name:"Chicken Wings",price:null,category:"broiler",image:"images/wings.jpg",available:true,description:"18–20 pieces · price to be confirmed"},
    {id:"breast-boneless",name:"Chicken Breast Boneless",price:null,category:"broiler",image:"images/breast-boneless.jpg",available:true,description:"Pack of 2 · price to be confirmed"},
    {id:"boneless-cubes",name:"Chicken Boneless (Cubes)",price:null,category:"broiler",image:"images/boneless-cubes.jpg",available:true,description:"18–20 pieces · price to be confirmed"},
    {id:"boneless-cubes-1kg",name:"Chicken Boneless (Cubes) (1 Kg)",price:599,category:"broiler",image:"images/boneless-cubes-1kg.jpg",available:true,description:"35–40 pieces · screenshot price"},
    {id:"biryani-skin-off",name:"Chicken Biryani Cut (Skin Off)",price:195,category:"broiler",image:"images/biryani-skin-off.jpg",available:true,description:"5–6 pieces · screenshot price"},
    {id:"thigh-leg-boneless",name:"Chicken Thigh & Leg (Boneless)",price:299,category:"broiler",image:"images/thigh-leg-boneless.jpg",available:true,description:"18–20 pieces · screenshot price"},
    {id:"biryani-skin-on",name:"Chicken Biryani Cut (Skin On)",price:null,category:"broiler",image:"images/biryani-skin-on.jpg",available:true,description:"5–6 pieces · price to be confirmed"},
    {id:"lollipop",name:"Chicken Lollipop",price:null,category:"broiler",image:"images/lollipop.jpg",available:true,description:"5–6 pieces · price to be confirmed"},
    {id:"minced",name:"Minced Chicken",price:299,category:"broiler",image:"images/minced.jpg",available:true,description:"Deboned minced chicken · screenshot price"},
    {id:"country",name:"Country Chicken",price:409,category:"live",image:"images/country.jpg",available:true,description:"Customise your cut · starts from"},
    {id:"whole-leg",name:"Chicken Whole Leg",price:199,category:"broiler",image:"images/whole-leg.jpg",available:false,description:"Pack of 2 · marked unavailable in reference"},
    {id:"drumsticks",name:"Chicken Drumsticks",price:null,category:"broiler",image:"images/drumsticks.jpg",available:true,description:"Price to be confirmed"},
    {id:"smoky-country",name:"Smoky Country Chicken (Turmeric)",price:null,category:"live",image:"images/smoky-country.jpg",available:true,description:"650–800 g · price to be confirmed"},
    {id:"gizzard",name:"Chicken Gizzard",price:null,category:"broiler",image:"images/gizzard.jpg",available:true,description:"Price to be confirmed"},
    {id:"broiler",name:"Broiler Chicken",price:260,category:"broiler",image:"images/curry-skin-off.jpg",available:true,description:"Price per kg"}
  ]
};